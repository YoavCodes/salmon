fin.meta.count2 = fin.meta.count2 || 1;


```a`, {href: `/#!/`, style: `position: absolute; top: 25px; right: 25px; font-weight: bold`}, rootNode, `Home (This link is from 'templates/test/hashbang.js')// render count: ` + fin.meta.count2); 

fin.meta.count2++