// node.js configuration

exports.config = {
	env: 'dev',// 'dev', 'staging', 'prod'
	port: 8200,
	/*
		'dev':
			- disable template caching
	*/
	
}